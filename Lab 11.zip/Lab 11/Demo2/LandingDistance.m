function [xLand] = LandingDistance(distanceVector, v0, theta)
%Landing Distance Calculates final landing distance from inputs d1, d2, d3,
%   v0, and theta
%Gavin Tobin, u1227373, ME EN 1010, HW3
    g = 9.81; %m / s ^ 2
    [x0, y0] = InitialCoords (distanceVector, theta);
    [v0x, v0y] = InitialVelocityComponents (v0, theta);
    tLand = Quadratic (-g / 2, v0y, y0, -1);
    xLand = (v0x .* tLand) + x0;
    if nargout == 0
        %set up plot and plot distance versus range
        plot (theta, xLand, 'b');
    end
end

