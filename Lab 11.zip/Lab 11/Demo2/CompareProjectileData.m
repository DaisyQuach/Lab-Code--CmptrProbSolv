function [sumSquaredError] = CompareProjectileData(v0, distanceVector, thetaL, expLanding)
%Find the SSE of the theoretical and experimental landing distances
    [xLand] = LandingDistance(distanceVector, v0, thetaL);
    [sumSquaredError] = SumOfSquaredErrors(xLand, expLanding);
end

