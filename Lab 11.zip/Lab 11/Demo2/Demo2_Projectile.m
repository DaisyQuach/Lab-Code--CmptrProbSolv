%%%%%%%%%%%%%%%%%%
% Gavin Tobin
% u1227373
% ME EN 1010 Lab Section 007
% Demo2
% Due April 16 2021
%%%%%%%%%%%%%%%%%%
clear,clc;

%%
clc;
load d_vector.mat;
[launchAngles, aveDistance] = ProjectileData ('Team11_ProjectileData.xlsx');

compare = @CompareProjectileData;
[best_v0, best_SSE] = fminbnd (compare, 0, 5, [], d, launchAngles, aveDistance)

hold on;
%data on plot
ProjectileData ('Team11_ProjectileData.xlsx');
LandingDistance(d, best_v0, launchAngles);
%set up text on plot
legend ('experiment', 'theory');
sse_string = sprintf ('The SSE is %.4f for an initial velocity of %.2f m/s', best_SSE, best_v0);
text (24, .3, sse_string);

%%
clc;
load d_vector.mat;
v0 = best_v0; %m/s
xTarget = [.8, .95, 1.1, 1.25]; %set up target vector
%xTarget = [.85, 1.0, 1.15, 1.3];

[launchTheta] = LaunchAngle(d, v0, xTarget);
for i = 1:length(xTarget)
    fprintf ("To hit a target at %.2f m the launch angle should be %.2f degrees\n", xTarget(i), launchTheta(i));
    i = i + 1;
end