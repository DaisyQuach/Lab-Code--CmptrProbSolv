function thetaL = ThetaLaunch(params, lengthsVector, thetaS)
%calculate launch angle with L_vector, servo motor angle, and alpha, beta,
%and thetaL0
%Gavin Tobin, u1227373

% Index alpha, beta, and thetaL0 out of the params vector
alpha = params (1); %offset angle in degrees
beta = params (2); %scaling factor
thetaL0 = params (3); %initial angle

% Compute thetaSC
thetaSC = alpha + (beta .* thetaS);

% Compute theta2
theta2 = 180 - thetaS + thetaSC;

% Compute theta4 by calling your ThetaFour function
theta4 = ThetaFour(lengthsVector, theta2);

% Compute thetaL
thetaL = 180 - theta4 + thetaL0;

%generate plot of thetaS v. thetaL if no output assigned
if nargout == 0
    plot (thetaS, thetaL, 'b');
    title ('Cannon Fourbar Kinematics');
    xlabel ('Servomotor angle [deg]');
    ylabel ('Launch angle [deg]');
end
end