function [v0x, v0y] = InitialVelocityComponents (v0, theta)
    % use this function to calculate intial velocity given v0 and theta
    % Inputs:v0: initial velocity of projectile
    %        theta: angle of launch of projectile in degrees
    % Outputs: v0x: initial speed in x direction
    %          v0y: initial speed in y direction
    % Gavin Tobin, u1227373, ME EN 1010, HW2

    v0x = v0 * cosd(theta);
    v0y = v0 * sind(theta);
end

