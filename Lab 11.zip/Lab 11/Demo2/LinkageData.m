function [aveLaunchAngles, servoAngles] = LinkageData (filename)
%analyzes the data in an excel spreadsheet named "filename"
%gives launch angles and average horizontal distances

%intialize variables and read matrices and assign to different matrices
data = readmatrix (filename); %imports data


servoAngles = data (:,1); %makes launch angle column array
servoAngles = servoAngles';

launchAnglesTemp = data (:,[2:end]); %makes temporary servo angle matrix 
aveLaunchAngles = mean (launchAnglesTemp');


    if nargout == 0
        %set up plot and plot servo angles versus launch angles
        plot (servoAngles, aveLaunchAngles, 'or');
        title ('Cannon Fourbar Kinematics');
        xlabel ('Servomotor angle [deg]');
        ylabel ('Launch angle [deg]');
    end
end