function [sumSquareErrors_expVTheory] = CompareLinkageData(params, linkLengths, expThetaS, thetaLExp)
%all inputs are vectors. Use this function to find the minimum error.
%Gavin Tobin, ME EN 1010, u1227373, HW10
thetaL = ThetaLaunch ( params, linkLengths, expThetaS);
sumSquareErrors_expVTheory = SumOfSquaredErrors (thetaL, thetaLExp);
end

