clc;
load d_vector.mat
load H_vector.mat
v0 = 3.31; %v0 from team 11 data
params = [18.597182121736722,0.058269090376978,12.350945226266433]; %params from team 11 data
xTarget = [.8, .95, 1.1, 1.25];
%xTarget = [.85, 1, 1.15, 1.3];
[launchVector] = LaunchAngle(d, v0, xTarget);
[thetaS] = ThetaServo(H, launchVector, params);
for i = 1:4
    fprintf ("To hit a target at %.2f meters, use a servo angle of %.2f degrees to get a launch angle of %.2f degrees\n", xTarget(i), thetaS(i), launchVector(i));
    i = i + 1;
end