%%%%%%%%%%%%%%%%%%
% Gavin Tobin
% u1227373
% ME EN 1010 Lab Section 007
% Demo2
% Due 16 Apr 2021
%%%%%%%%%%%%%%%%%%
clear,clc;

%%
clc, close ALL;
params = [30.0, .01, 13.0];
load L_vector;
[aveLaunchAngles, servoAngles] = LinkageData ('Team11_LinkageData.xlsx'); %find launcgh and servo angles from given data
compareLink = @CompareLinkageData; %function handle for CompareLinkageData

%optimize parameters for experimental data
[optimal_params, SSE] = fminsearch (compareLink, [0, 0, 0], [], L_vector, servoAngles, aveLaunchAngles)

%set up plot and plot data
hold on;
LinkageData ('Team11_LinkageData.xlsx');
ThetaLaunch (optimal_params, L_vector, servoAngles);
legend ('experiment', 'theory', 'Location', 'southeast');
%set up all the text for the plot
alpha_text = sprintf ('alpha = %.2f', optimal_params(1));
beta_text = sprintf ('beta = %.2f', optimal_params(2));
thetaL0_text = sprintf ('thetaL0 = %.2f', optimal_params(3));
SSE_text = sprintf ('SSE = %.4f', SSE);

text (20, 80, alpha_text);
text (20, 75, beta_text);
text (20, 70, thetaL0_text);
text (20, 65, SSE_text);

%%
% load H_vector.mat to make H available in the workspace
load H_vector.mat;

% initialize thetaL to one of the test case values
thetaL = [47, 54, 61, 68];
%thetaL = [45, 51, 57, 63];

% initialize the params vector
params = optimal_params;

% call your function
[thetaS] = ThetaServo(H, thetaL, params);

%print message for thetaS v thetaL
for i = 1:4
    fprintf ("Use servo angle %.2f degrees to get a launch angle of %.2f degrees\n", thetaS(i), thetaL(i));
    i = i + 1;
end