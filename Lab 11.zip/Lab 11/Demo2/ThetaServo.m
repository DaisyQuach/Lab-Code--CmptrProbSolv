function [thetaS] = ThetaServo(hVector, thetaL, params)
%find the servo angles for certain launch angles
    %index out variables from params vector
    alpha = params(1);
    beta = params(2);
    thetaL0 = params(3);
    
    theta2 = thetaL - thetaL0;
    theta4 = ThetaFour(hVector, theta2);
    
    thetaS = (theta4 + alpha) / (1 - beta);
end